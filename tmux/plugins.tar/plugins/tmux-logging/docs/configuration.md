# Custom configuration

The default logging path is `$HOME` To change that, add `set -g @logging-path "path"` to `.tmux.conf` file 
